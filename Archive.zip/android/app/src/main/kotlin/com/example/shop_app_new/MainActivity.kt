package com.example.shop_app_new

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
