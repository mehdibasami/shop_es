import 'dart:convert';
import 'dart:developer';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shop_app_new/constants.dart';
import 'package:dio/dio.dart' as dio;

import './cart.dart';

class OrderItem {
  final String id;
  final double amount;
  final List<CartItem> products;
  final DateTime dateTime;

  OrderItem({
    @required this.id,
    @required this.amount,
    @required this.products,
    @required this.dateTime,
  });
}

class Orders with ChangeNotifier {
  List<OrderItem> _orders = [];
  final String authToken;
  final String userId;

  Orders(this.authToken, this.userId, this._orders);

  List<OrderItem> get orders {
    return [..._orders];
  }

  Future<void> fetchAndSetOrders() async {
    try {
      final url = '${Constants.BaseUrl}/order';
      final response = await http.get(url);
      final List<OrderItem> loadedOrders = [];
      final extractedData = json.decode(response.body) as List;
      if (extractedData == null) {
        return;
      }

      for (var element in extractedData) {
        loadedOrders.add(
          OrderItem(
            id: element['_id'] ?? DateTime.now().toIso8601String(),
            amount: double.parse(element['totalAmount'] ?? '1.0'),
            dateTime: DateTime.parse(element['date']),
            products: (element['cartProducts'] as List<dynamic>)
                .map(
                  (item) => CartItem(
                    id: item['id'],
                    price: item['price'],
                    quantity: item['quantity'],
                    title: item['title'],
                  ),
                )
                .toList(),
          ),
        );
      }
      _orders = loadedOrders.reversed.toList();
      notifyListeners();
    } catch (e) {
      log('err: ' + e);
    }
  }

  Future<void> addOrder(List<CartItem> cartProducts, double total) async {
    final url = '${Constants.BaseUrl}/order';
    final timestamp = DateTime.now();
    await dio.Dio().post(
      url,
      data: json.encode({
        'totalAmount': total,
        'dateTime': timestamp.toIso8601String(),
        'cartProducts': cartProducts
            .map((cp) => {
                  'id': cp.id,
                  'title': cp.title,
                  'quantity': cp.quantity,
                  'price': cp.price,
                })
            .toList(),
      }),
    );
    // var data = jsonDecode(response.data);
    // log(data);
    _orders.insert(
      0,
      OrderItem(
        id: DateTime.now().toIso8601String(),
        amount: total,
        dateTime: timestamp,
        products: cartProducts,
      ),
    );
    notifyListeners();
  }
}
