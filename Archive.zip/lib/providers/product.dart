import 'package:flutter/material.dart';

class ProductCategories {
  bool mahboob;
  bool newProducts;
  bool offers;
  bool cloth;
  bool shoes;
  bool health;
  bool beauty;
  ProductCategories({
    this.cloth = false,
    this.mahboob = false,
    this.shoes = false,
    this.offers = false,
    this.newProducts = false,
    this.beauty = false,
    this.health = false,
  });
  ProductCategories.fromJson(Map json) {
    this.cloth = json['cloth'] ?? false;
    this.mahboob = json['mahboob'] ?? false;
    this.shoes = json['shoes'] ?? false;
    this.offers = json['offers'] ?? false;
    this.newProducts = json['newProducts'] ?? false;
    this.health = json['health'] ?? false;
    this.beauty = json['beauty'] ?? false;
  }
  Map<String, dynamic> toJson() => {
        'cloth': cloth,
        'mahboob': mahboob,
        'shoes': shoes,
        'offers': offers,
        'newProducts': newProducts,
        'beauty': beauty,
        'health': health,
      };
}

class Availability {
  String id;
  String color;
  String size;
  int quantity;
  int max;
  Availability({
    this.id = '',
    this.color = '',
    this.size = '',
    this.quantity = 0,
    this.max = 20,
  });
  Availability.fromJson(Map json) {
    this.id = json['id'];
    this.color = json['color'];
    this.quantity = json['quantity'] ?? 0;
    this.size = json['size'];
    this.max = json['max'] ?? 20;
  }
  Map<String, dynamic> toJson() => {
        'id': id,
        'color': color,
        'quantity': quantity,
        'size': size,
        'max': max,
      };
}

class Product with ChangeNotifier {
  String id;
  ProductCategories categories;
  String catId;
  String title;
  List<Availability> availability;
  String price;
  String hazineErsal;
  String offPresent;
  String brand;
  String description;
  String vizhegiha;
  String imageUrl;
  List imagesArray;
  int likes;
  int favrites;
  bool isFavorite;

  Product({
    this.id = '',
    this.categories,
    this.catId = '',
    this.title = '',
    this.isFavorite = false,
    this.price = '',
    this.hazineErsal = '10000',
    this.availability,
    this.offPresent = '',
    this.brand = '',
    this.imageUrl = '',
    this.description = '',
    this.vizhegiha = '',
    this.imagesArray,
    this.likes = 0,
    this.favrites = 0,
  });

  Product.fromJson(Map json) {
    List<Availability> av() {
      List<Availability> m = [];
      if (json['availability'] != null) {
        json['availability'].forEach((e) {
          m.add(Availability.fromJson(e));
        });
      }
      return m;
    }

// print('-----------------${ json['_id']}');
    this.id = json['_id'];
    // this.categories = ProductCategories.fromJson(json['categories']);
    this.catId = json['catId'];
    this.title = json['title'];
    this.price = json['price'];
    this.imageUrl = json['ImageUrl'] ??
            (json['imagesArray'] != null &&
                (json['imagesArray'] as List).isNotEmpty)
        ? json['imagesArray'][0]
        : '';
    this.hazineErsal = json['hazineErsal'];
    this.availability = json['availability'] != null ? av() : [];
    this.offPresent = json['offPresent'];
    this.brand = json['brand'];
    this.description = json['description'];
    this.vizhegiha = json['vizhegiha'];
    this.imagesArray = json['imagesArray'];
    this.favrites = json['favrites'];
    this.isFavorite = json['isFavorite'] ?? false;
    this.likes = json['likes'];
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'categories': categories,
        'catId': catId,
        'title': title,
        'price': price,
        'hazineErsal': hazineErsal,
        'availability': availability,
        'offPresent': offPresent,
        'brand': brand,
        'description': description,
        'vizhegiha': vizhegiha,
        'imagesArray': imagesArray,
        'ImageUrl': imageUrl,
        'isFavorite': isFavorite,
      };
}
