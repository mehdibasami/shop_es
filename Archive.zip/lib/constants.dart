class Constants {
  static const BaseUrl = 'http://192.168.191.253:3000';
}
